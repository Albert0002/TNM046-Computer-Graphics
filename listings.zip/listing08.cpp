// --- Add this line to your includes
#include "Utilities.hpp"

// --- Insert this line into your rendering loop.
util::displayFPS(window);
