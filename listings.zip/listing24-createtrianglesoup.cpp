// --- Put this before your rendering loop
// Generate a triangle
TriangleSoup myShape;
myShape.createTriangle();

// --- Put this in the rendering loop
// Draw the triangle
myShape.render();
